mona
====

Corelan Repository for mona.py


Installation instructions
-------------------------

### Immunity Debugger
1. drop mona.py into the 'PyCommands' folder (inside the Immunity Debugger application folder).
2. install Python 2.7.14 (or a higher 2.7.xx version) into c:\python27, thus overwriting the version that was bundled with Immunity. This is needed to avoid TLS issues when trying to update mona.  Make sure you are installing the 32bit version of python.

### WinDBG
See https://github.com/corelan/windbglib



notes
-----

mona.py has been inventoried at Rawsec's CyberSecurity Inventory
[![Rawsec's CyberSecurity Inventory](https://inventory.rawsec.ml/img/badges/Rawsec-inventoried-FF5050_plastic.svg)](https://inventory.rawsec.ml/)